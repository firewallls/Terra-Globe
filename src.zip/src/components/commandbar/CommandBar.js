// ══════════════════════════════════════════════
//  COMMAND BAR — Search Component
//  Matches TERRA design spec (terra.html ref)
// ══════════════════════════════════════════════

let allCountries = [];
let currentFilter = { search: '', region: '', pop: 0 };
let currentSort = 'name';
let debounceTimer = null;
let isOpen = false;
let dataLoaded = false;

const REGIONS = ['Africa', 'Americas', 'Asia', 'Europe', 'Oceania'];
const POP_FILTERS = [
  { label: '1M+ Pop', value: 1_000_000 },
  { label: '100M+ Pop', value: 100_000_000 },
];
const SORT_OPTIONS = [
  { label: 'Name',   value: 'name' },
  { label: 'Pop ↓',  value: 'pop-desc' },
  { label: 'Pop ↑',  value: 'pop-asc' },
  { label: 'Area ↓', value: 'area-desc' },
];

// ── Utils ──────────────────────────────────────
function formatNum(n) {
  if (!n) return '—';
  if (n >= 1_000_000_000) return (n / 1_000_000_000).toFixed(1) + 'B';
  if (n >= 1_000_000)     return (n / 1_000_000).toFixed(1) + 'M';
  if (n >= 1_000)         return (n / 1_000).toFixed(0) + 'K';
  return n.toString();
}

// ── Filter & Sort ──────────────────────────────
function getFiltered() {
  const q = currentFilter.search.trim().toLowerCase();
  return allCountries
    .filter(c => {
      if (currentFilter.region && c.region !== currentFilter.region) return false;
      if (currentFilter.pop && (c.population || 0) < currentFilter.pop) return false;
      if (!q) return true;
      const name    = (c.name?.common || '').toLowerCase();
      const capital = (c.capital?.[0] || '').toLowerCase();
      const region  = (c.region || '').toLowerCase();
      return name.includes(q) || capital.includes(q) || region.includes(q);
    })
    .sort((a, b) => {
      switch (currentSort) {
        case 'pop-desc': return (b.population || 0) - (a.population || 0);
        case 'pop-asc':  return (a.population || 0) - (b.population || 0);
        case 'area-desc': return (b.area || 0) - (a.area || 0);
        default: return (a.name?.common || '').localeCompare(b.name?.common || '');
      }
    });
}

// ── Render Results ─────────────────────────────
function renderResults() {
  const list  = document.getElementById('cmd-results-list');
  const count = document.getElementById('cmd-results-count');
  if (!list || !count) return;

  const filtered = getFiltered();
  count.textContent = `${filtered.length} ${filtered.length === 1 ? 'country' : 'countries'}`;

  if (!dataLoaded) {
    list.innerHTML = `<div class="cmd-empty">Loading countries…</div>`;
    return;
  }

  if (filtered.length === 0) {
    list.innerHTML = `<div class="cmd-empty">No results for "<em>${currentFilter.search}</em>"</div>`;
    return;
  }

  list.innerHTML = filtered.map(c => `
    <div class="cmd-result-row" data-cca3="${c.cca3}">
      <span class="cmd-result-flag">${c.flag || '🌐'}</span>
      <div class="cmd-result-info">
        <div class="cmd-result-name">${c.name?.common || '—'}</div>
        <div class="cmd-result-sub">${c.capital?.[0] || '—'} · ${c.region || '—'}</div>
      </div>
      <span class="cmd-result-pop">${formatNum(c.population)}</span>
    </div>
  `).join('');
}

// ── Open / Close ───────────────────────────────
export function openCommandBar() {
  isOpen = true;
  const bar = document.getElementById('command-bar');
  if (!bar) return;
  bar.classList.add('open');
  const input = document.getElementById('cmd-input');
  if (input) { input.focus(); input.select(); }
}

export function closeCommandBar() {
  isOpen = false;
  const bar = document.getElementById('command-bar');
  if (bar) bar.classList.remove('open');
}

export function toggleCommandBar() {
  isOpen ? closeCommandBar() : openCommandBar();
}

// ── Data Loading ───────────────────────────────
async function loadCountries() {
  try {
    const res  = await fetch(
      'https://restcountries.com/v3.1/all?fields=name,capital,region,subregion,population,area,cca3,flag'
    );
    allCountries = await res.json();
    dataLoaded   = true;
    renderResults();
  } catch (e) {
    dataLoaded = true;
    const list = document.getElementById('cmd-results-list');
    if (list) list.innerHTML = `<div class="cmd-empty">Failed to load countries.</div>`;
  }
}

// ── Mount ──────────────────────────────────────
export default function CommandBar(mountEl) {
  // ── Inject styles ──
  if (!document.getElementById('cmd-bar-styles')) {
    const style = document.createElement('style');
    style.id = 'cmd-bar-styles';
    style.textContent = `
      /* ── Command Bar Shell ── */
      #command-bar {
        position: fixed;
        top: 64px;
        left: 50%;
        transform: translateX(-50%) translateY(-16px) scale(0.97);
        width: min(560px, calc(100vw - 32px));
        max-height: min(620px, calc(100vh - 96px));
        background: var(--color-overlay-command);
        backdrop-filter: blur(32px);
        -webkit-backdrop-filter: blur(32px);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-default, 4px);
        box-shadow: var(--shadow-command);
        z-index: 300;
        opacity: 0;
        pointer-events: none;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        transition:
          opacity 0.30s cubic-bezier(0.16,1,0.3,1),
          transform 0.30s cubic-bezier(0.16,1,0.3,1);
      }

      #command-bar.open {
        opacity: 1;
        pointer-events: all;
        transform: translateX(-50%) translateY(0) scale(1);
      }

      /* ── Accent line ── */
      .cmd-accent-line {
        height: 2px;
        background: linear-gradient(90deg, var(--color-signal) 0%, rgba(0,229,255,0.25) 60%, transparent 100%);
        flex-shrink: 0;
        transform-origin: left;
        transform: scaleX(0);
        transition: transform 0.35s 0.08s ease;
      }
      #command-bar.open .cmd-accent-line { transform: scaleX(1); }

      /* ── Search row ── */
      .cmd-search-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 0 16px;
        height: 52px;
        border-bottom: 1px solid var(--color-border);
        flex-shrink: 0;
      }

      .cmd-search-icon {
        color: var(--color-signal);
        font-size: 16px;
        flex-shrink: 0;
      }

      #cmd-input {
        flex: 1;
        background: none;
        border: none;
        outline: none;
        font-family: var(--font-familjen, 'Familjen Grotesk', sans-serif);
        font-size: 15px;
        color: var(--color-text-primary);
        min-width: 0;
      }
      #cmd-input::placeholder { color: var(--color-text-tertiary); }

      .cmd-esc-badge {
        padding: 3px 6px;
        background: var(--color-surface-mid);
        border: 1px solid var(--color-border-strong);
        border-radius: 3px;
        font-family: var(--font-azeret-mono, monospace);
        font-size: 9px;
        letter-spacing: 0.1em;
        color: var(--color-text-tertiary);
        cursor: pointer;
        flex-shrink: 0;
        user-select: none;
        transition: color 0.15s, border-color 0.15s;
      }
      .cmd-esc-badge:hover { color: var(--color-text-secondary); border-color: var(--color-border-strong); }

      /* ── Filter chips ── */
      .cmd-filters-row {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        padding: 10px 16px;
        border-bottom: 1px solid var(--color-border);
        flex-shrink: 0;
      }

      .cmd-filter-chip {
        padding: 0 10px;
        height: 26px;
        display: flex;
        align-items: center;
        background: var(--color-surface-mid);
        border: 1px solid var(--color-border);
        border-radius: 13px;
        font-family: var(--font-familjen, sans-serif);
        font-size: 10px;
        font-weight: 500;
        letter-spacing: 0.08em;
        color: var(--color-text-secondary);
        cursor: pointer;
        text-transform: uppercase;
        transition: all 0.15s;
        user-select: none;
      }
      .cmd-filter-chip:hover {
        border-color: var(--color-border-strong);
        color: var(--color-text-primary);
      }
      .cmd-filter-chip.active {
        background: var(--color-signal-tint);
        border-color: var(--color-signal);
        color: var(--color-signal);
      }

      /* ── Sort row ── */
      .cmd-sort-row {
        display: flex;
        align-items: center;
        padding: 0 16px;
        height: 38px;
        border-bottom: 1px solid var(--color-border);
        flex-shrink: 0;
        gap: 0;
      }
      .cmd-sort-label {
        font-family: var(--font-azeret-mono, monospace);
        font-size: 9px;
        font-weight: 300;
        letter-spacing: 0.15em;
        color: var(--color-text-tertiary);
        text-transform: uppercase;
        margin-right: 12px;
        flex-shrink: 0;
      }
      .cmd-sort-item {
        padding: 0 10px;
        height: 38px;
        display: flex;
        align-items: center;
        font-family: var(--font-familjen, sans-serif);
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        color: var(--color-text-tertiary);
        cursor: pointer;
        position: relative;
        transition: color 0.15s;
        user-select: none;
        flex-shrink: 0;
      }
      .cmd-sort-item:hover { color: var(--color-text-secondary); }
      .cmd-sort-item.active { color: var(--color-text-primary); }
      .cmd-sort-item.active::after {
        content: '';
        position: absolute;
        bottom: 0; left: 10px; right: 10px;
        height: 2px;
        background: var(--color-signal);
        border-radius: 1px;
      }

      /* ── Results header ── */
      .cmd-results-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 16px 4px;
        flex-shrink: 0;
      }
      .cmd-results-label {
        font-family: var(--font-azeret-mono, monospace);
        font-size: 9px;
        font-weight: 300;
        letter-spacing: 0.15em;
        color: var(--color-text-tertiary);
        text-transform: uppercase;
      }
      #cmd-results-count {
        font-family: var(--font-azeret-mono, monospace);
        font-size: 10px;
        color: var(--color-text-secondary);
      }

      /* ── Results list ── */
      #cmd-results-list {
        overflow-y: auto;
        flex: 1;
        min-height: 0;
        scroll-behavior: smooth;
      }
      #cmd-results-list::-webkit-scrollbar { width: 3px; }
      #cmd-results-list::-webkit-scrollbar-track { background: transparent; }
      #cmd-results-list::-webkit-scrollbar-thumb { background: var(--color-signal-tint); border-radius: 2px; }

      .cmd-result-row {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 0 16px;
        height: 52px;
        cursor: pointer;
        position: relative;
        transition: background 0.12s;
        border-bottom: 1px solid var(--color-border);
      }
      .cmd-result-row::before {
        content: '';
        position: absolute;
        left: 0; top: 0; bottom: 0;
        width: 3px;
        background: var(--color-signal);
        transform: scaleX(0);
        transform-origin: left;
        transition: transform 0.12s;
      }
      .cmd-result-row:hover { background: var(--color-signal-tint); }
      .cmd-result-row:hover::before { transform: scaleX(1); }
      .cmd-result-row:last-child { border-bottom: none; }

      .cmd-result-flag {
        font-size: 18px;
        flex-shrink: 0;
        width: 24px;
        text-align: center;
      }
      .cmd-result-info { flex: 1; min-width: 0; }
      .cmd-result-name {
        font-family: var(--font-familjen, sans-serif);
        font-size: 13px;
        font-weight: 500;
        color: var(--color-text-primary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .cmd-result-sub {
        font-family: var(--font-azeret-mono, monospace);
        font-size: 10px;
        font-weight: 300;
        color: var(--color-text-secondary);
        letter-spacing: 0.05em;
      }
      .cmd-result-pop {
        font-family: var(--font-azeret-mono, monospace);
        font-size: 11px;
        font-weight: 300;
        color: var(--color-text-tertiary);
        flex-shrink: 0;
      }

      .cmd-empty {
        padding: 32px 16px;
        text-align: center;
        font-family: var(--font-azeret-mono, monospace);
        font-size: 11px;
        letter-spacing: 0.08em;
        color: var(--color-text-tertiary);
      }
      .cmd-empty em { color: var(--color-text-secondary); font-style: normal; }
    `;
    document.head.appendChild(style);
  }

  // ── Mount HTML ──
  mountEl.innerHTML = `
    <div id="command-bar">
      <div class="cmd-accent-line"></div>

      <div class="cmd-search-row">
        <span class="cmd-search-icon">⌕</span>
        <input
          id="cmd-input"
          type="text"
          placeholder="Search country, capital or region…"
          autocomplete="off"
          spellcheck="false"
        >
        <span class="cmd-esc-badge" id="cmd-esc-badge">ESC</span>
      </div>

      <div class="cmd-filters-row" id="cmd-filters-row">
        <div class="cmd-filter-chip active" data-region="">ALL</div>
        ${REGIONS.map(r => `<div class="cmd-filter-chip" data-region="${r}">${r}</div>`).join('')}
        ${POP_FILTERS.map(p => `<div class="cmd-filter-chip" data-pop="${p.value}">${p.label}</div>`).join('')}
      </div>

      <div class="cmd-sort-row">
        <div class="cmd-sort-label">Sort:</div>
        ${SORT_OPTIONS.map((s, i) => `
          <div class="cmd-sort-item ${i === 0 ? 'active' : ''}" data-sort="${s.value}">${s.label}</div>
        `).join('')}
      </div>

      <div class="cmd-results-header">
        <span class="cmd-results-label">Results</span>
        <span id="cmd-results-count">— countries</span>
      </div>

      <div id="cmd-results-list">
        <div class="cmd-empty">Loading countries…</div>
      </div>
    </div>
  `;

  // ── Wire: input ──
  const input = document.getElementById('cmd-input');
  input.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      currentFilter.search = input.value;
      renderResults();
    }, 240);
  });

  // ── Wire: ESC badge ──
  document.getElementById('cmd-esc-badge').addEventListener('click', closeCommandBar);

  // ── Wire: region filter chips ──
  document.querySelectorAll('.cmd-filter-chip[data-region]').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('.cmd-filter-chip[data-region]').forEach(c => c.classList.remove('active'));
      // also clear pop chips
      document.querySelectorAll('.cmd-filter-chip[data-pop]').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      currentFilter.region = chip.dataset.region;
      currentFilter.pop = 0;
      renderResults();
    });
  });

  // ── Wire: pop filter chips ──
  document.querySelectorAll('.cmd-filter-chip[data-pop]').forEach(chip => {
    chip.addEventListener('click', () => {
      const wasActive = chip.classList.contains('active');
      document.querySelectorAll('.cmd-filter-chip[data-pop]').forEach(c => c.classList.remove('active'));
      document.querySelectorAll('.cmd-filter-chip[data-region]').forEach(c => c.classList.remove('active'));
      // reset region to ALL
      document.querySelector('.cmd-filter-chip[data-region=""]').classList.add('active');
      currentFilter.region = '';
      if (wasActive) {
        currentFilter.pop = 0;
      } else {
        chip.classList.add('active');
        currentFilter.pop = parseInt(chip.dataset.pop, 10);
      }
      renderResults();
    });
  });

  // ── Wire: sort ──
  document.querySelectorAll('.cmd-sort-item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.cmd-sort-item').forEach(s => s.classList.remove('active'));
      item.classList.add('active');
      currentSort = item.dataset.sort;
      renderResults();
    });
  });

  // ── Wire: keyboard shortcuts ──
  document.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
      e.preventDefault();
      toggleCommandBar();
    }
    if (e.key === 'Escape' && isOpen) {
      closeCommandBar();
    }
  });

  // ── Wire: click outside to close ──
  document.addEventListener('mousedown', e => {
    const bar = document.getElementById('command-bar');
    if (bar && !bar.contains(e.target)) {
      const searchBtn = document.querySelector('.search-icon-hover');
      if (searchBtn && searchBtn.contains(e.target)) return;
      closeCommandBar();
    }
  });

  // ── Load data ──
  loadCountries();
}
